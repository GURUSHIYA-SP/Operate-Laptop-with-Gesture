
import mediapipe as mp
from mediapipe.tasks import python
import cv2
from mediapipe.tasks.python import vision

model_path = r'C:\Users\GURUSHIYA\PycharmProjects\Gesture\venv\Lib\site-packages\gesture_recognizer.task'


BaseOptions = mp.tasks.BaseOptions
base_options = BaseOptions(model_asset_path= model_path)
GestureRecognizer = mp.tasks.vision.GestureRecognizer
GestureRecognizerOptions = mp.tasks.vision.GestureRecognizerOptions
GestureRecognizerResult = mp.tasks.vision.GestureRecognizerResult
VisionRunningMode = mp.tasks.vision.RunningMode


# Create a gesture recognizer instance with the live stream mode:
def print_result(result: GestureRecognizerResult, output_image: mp.Image, timestamp_ms: int):
    print('gesture recognition result: {}'.format(result))


options = GestureRecognizerOptions(
    base_options=BaseOptions(model_asset_path='/path/to/model.task'),
    running_mode=VisionRunningMode.LIVE_STREAM,
    result_callback=print_result)

with GestureRecognizer.create_from_options(options) as recognizer:
    # Use OpenCV’s VideoCapture to start capturing from the webcam.
    cap = cv2.VideoCapture(0)
'''
    # Create a loop to read the latest frame from the camera using VideoCapture#read()
    while True:
        # Read each frame from the webcam
        _, frame = cap.read()

        # Convert the frame received from OpenCV to a MediaPipe’s Image object.
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame)

        # Show the final output
        cv2.imshow("Output", frame)

        recognition_result = recognizer.recognize_async(mp_image, 50)
        top_gesture = recognition_result.gestures[0][0]

        if cv2.waitKey(1) == ord('q'):
            break
'''
# release the webcam and destroy all active windows
cap.release()
cv2.destroyAllWindows()