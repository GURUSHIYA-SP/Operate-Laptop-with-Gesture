import cv2
import mediapipe as mp

# Set up the Mediapipe pipeline
mp_hands = mp.solutions.hands
mp_gesture = mp.solutions.gesture
hands = mp_hands.Hands()
gesture = mp_gesture.Gesture()

# Read video frames from camera
cap = cv2.VideoCapture(1)

while True:
    # Read a frame from the camera
    ret, frame = cap.read()

    # Process the frame with the Mediapipe pipeline
    results = hands.process(frame)
    landmarks = results.multi_hand_landmarks[0]
    gesture_results = gesture.recognize(landmarks)

    # Interpret the gesture results
    if gesture_results.multi_handedness:
        hand = gesture_results.multi_handedness[0].classification[0].label
        gesture = gesture_results.multi_gesture[0].class_type
        print(f"Detected {gesture} gesture with {hand} hand")

    # Display the results on the screen
    cv2.imshow("frame", frame)
    if cv2.waitKey(1) == ord('q'):
        break

# Clean up
cap.release()
cv2.destroyAllWindows()